<?= $this->extend('admin/layout/template') ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Ini Halaman Dashboard</h4>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>